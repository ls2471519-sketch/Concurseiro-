# Desafio dos Concuserios — versão inicial

## O que já funciona
- Tela inicial
- Jogo com 15 questões de exemplo
- 5 vidas por partida
- +10 pontos e +2 moedas por acerto
- Perda de uma vida por erro
- Dificuldade progressiva em três fases
- Explicação após cada resposta
- Melhor pontuação, moedas e ranking local persistidos no aparelho

## Requisitos
- Flutter SDK instalado
- Android Studio (com Android SDK) ou VS Code configurado para Flutter

## Como executar
1. Extraia o ZIP.
2. Abra a pasta `desafio_dos_concuserios` no Android Studio ou VS Code.
3. No terminal, execute:
   flutter pub get
   flutter run

## Como gerar APK
No terminal, dentro da pasta do projeto:
   flutter build apk --release

O APK será gerado em:
   build/app/outputs/flutter-apk/app-release.apk

## Observações
- O ranking é local, não é compartilhado entre aparelhos.
- As perguntas são exemplos iniciais e devem ser revisadas/ampliadas antes de uma publicação.
- O nome foi mantido exatamente como solicitado: "Desafio dos Concuserios".
