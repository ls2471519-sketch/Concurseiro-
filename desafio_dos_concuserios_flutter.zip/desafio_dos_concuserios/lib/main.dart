import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DesafioApp());
}

const navy = Color(0xFF101B35);
const blue = Color(0xFF1D3768);
const gold = Color(0xFFFFC857);
const bg = Color(0xFFF3F5FA);

class DesafioApp extends StatelessWidget {
  const DesafioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Desafio dos Concuserios',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        fontFamily: 'Roboto',
      ),
      home: const HomePage(),
    );
  }
}

class Question {
  final String subject;
  final String level;
  final String text;
  final List<String> options;
  final int answer;
  final String explanation;

  const Question({
    required this.subject,
    required this.level,
    required this.text,
    required this.options,
    required this.answer,
    required this.explanation,
  });
}

const questions = <Question>[
  Question(
    subject: 'Português',
    level: 'Fácil',
    text: 'Assinale a alternativa em que a palavra está escrita corretamente.',
    options: ['Excessão', 'Exceção', 'Esceção', 'Excesssão'],
    answer: 1,
    explanation: 'A grafia correta é “exceção”, com c e ç.',
  ),
  Question(
    subject: 'Matemática',
    level: 'Fácil',
    text: 'Um produto custa R\$ 80,00 e recebe desconto de 25%. Qual é o preço final?',
    options: ['R\$ 55,00', 'R\$ 60,00', 'R\$ 65,00', 'R\$ 70,00'],
    answer: 1,
    explanation: '25% de 80 é 20. Portanto, 80 − 20 = R\$ 60,00.',
  ),
  Question(
    subject: 'Conhecimentos Gerais',
    level: 'Fácil',
    text: 'Qual é a capital do estado de Alagoas?',
    options: ['Aracaju', 'Recife', 'Maceió', 'João Pessoa'],
    answer: 2,
    explanation: 'Maceió é a capital do estado de Alagoas.',
  ),
  Question(
    subject: 'Raciocínio Lógico',
    level: 'Fácil',
    text: 'Complete a sequência: 2, 4, 8, 16, __.',
    options: ['18', '24', '30', '32'],
    answer: 3,
    explanation: 'Cada termo é o dobro do anterior. Assim, 16 × 2 = 32.',
  ),
  Question(
    subject: 'Português',
    level: 'Médio',
    text: 'Na frase “Os candidatos chegaram cedo”, o sujeito é:',
    options: ['Oculto', 'Indeterminado', 'Os candidatos', 'Cedo'],
    answer: 2,
    explanation: '“Os candidatos” é o sujeito, pois pratica a ação expressa pelo verbo chegaram.',
  ),
  Question(
    subject: 'Matemática',
    level: 'Médio',
    text: 'Uma equipe realiza 120 cadastros em 4 dias, mantendo o mesmo ritmo. Quantos realizará em 7 dias?',
    options: ['180', '200', '210', '240'],
    answer: 2,
    explanation: '120 ÷ 4 = 30 cadastros por dia. Em 7 dias: 30 × 7 = 210.',
  ),
  Question(
    subject: 'Informática',
    level: 'Médio',
    text: 'Qual atalho é geralmente utilizado para copiar um texto selecionado no Windows?',
    options: ['Ctrl + X', 'Ctrl + C', 'Ctrl + V', 'Ctrl + Z'],
    answer: 1,
    explanation: 'Ctrl + C copia; Ctrl + X recorta; Ctrl + V cola; Ctrl + Z desfaz.',
  ),
  Question(
    subject: 'Direito Constitucional',
    level: 'Médio',
    text: 'Segundo a Constituição Federal de 1988, a casa é asilo inviolável do indivíduo. Em regra, nela ninguém pode entrar sem consentimento do morador, salvo situações previstas na Constituição. Qual alternativa apresenta uma dessas situações?',
    options: [
      'A qualquer hora, por ordem verbal de qualquer servidor.',
      'Durante a noite, por simples solicitação de vizinho.',
      'Em caso de flagrante delito ou desastre, para prestar socorro, ou, durante o dia, por determinação judicial.',
      'Sempre que houver denúncia anônima, sem outras condições.'
    ],
    answer: 2,
    explanation: 'O art. 5º, XI, prevê essas exceções: flagrante delito, desastre, prestação de socorro e, durante o dia, determinação judicial.',
  ),
  Question(
    subject: 'Raciocínio Lógico',
    level: 'Médio',
    text: 'Se todo recenseador é servidor temporário e João é recenseador, então:',
    options: [
      'João não trabalha temporariamente.',
      'João é servidor temporário.',
      'Todo servidor temporário é recenseador.',
      'Não é possível estabelecer nenhuma conclusão.'
    ],
    answer: 1,
    explanation: 'A conclusão decorre diretamente das duas premissas: João pertence ao grupo dos recenseadores e, portanto, ao grupo dos servidores temporários.',
  ),
  Question(
    subject: 'Português',
    level: 'Difícil',
    text: 'Assinale a frase em que o emprego da crase está correto.',
    options: [
      'O candidato começou à estudar.',
      'Entreguei o documento à diretora.',
      'Chegaremos à pé ao local.',
      'A prova será aplicada à partir das oito horas.'
    ],
    answer: 1,
    explanation: 'O verbo entregar exige a preposição “a”, e “diretora” admite o artigo “a”: ocorre a fusão à. Não há crase antes de verbo ou na expressão “a pé”.',
  ),
  Question(
    subject: 'Matemática',
    level: 'Difícil',
    text: 'Um salário de R\$ 2.000,00 recebe aumento de 10% e, depois, redução de 10% sobre o novo valor. Qual será o valor final?',
    options: ['R\$ 2.000,00', 'R\$ 1.980,00', 'R\$ 2.020,00', 'R\$ 1.800,00'],
    answer: 1,
    explanation: 'Após o aumento: 2.000 × 1,10 = 2.200. Após a redução: 2.200 × 0,90 = 1.980.',
  ),
  Question(
    subject: 'Informática',
    level: 'Difícil',
    text: 'Em segurança da informação, o que é autenticação em dois fatores (2FA)?',
    options: [
      'Usar duas senhas iguais.',
      'Fazer cópia de segurança em dois dispositivos.',
      'Exigir duas formas diferentes de comprovar a identidade do usuário.',
      'Compartilhar a senha com dois administradores.'
    ],
    answer: 2,
    explanation: 'A autenticação em dois fatores combina dois elementos de verificação, como senha e código temporário.',
  ),
  Question(
    subject: 'Direito Administrativo',
    level: 'Difícil',
    text: 'Qual princípio da Administração Pública exige atuação conforme a lei?',
    options: ['Publicidade', 'Legalidade', 'Eficiência', 'Moralidade'],
    answer: 1,
    explanation: 'O princípio da legalidade submete a atuação administrativa às normas jurídicas.',
  ),
  Question(
    subject: 'Conhecimentos Gerais',
    level: 'Difícil',
    text: 'O Brasil é organizado político-administrativamente em:',
    options: [
      'União, estados, Distrito Federal e municípios.',
      'União, províncias e territórios autônomos.',
      'Estados, comarcas e municípios.',
      'União, regiões e distritos.'
    ],
    answer: 0,
    explanation: 'O art. 18 da Constituição Federal estabelece a organização em União, estados, Distrito Federal e municípios.',
  ),
  Question(
    subject: 'Raciocínio Lógico',
    level: 'Difícil',
    text: 'Uma urna contém 3 bolas vermelhas e 2 azuis. Retirando uma bola ao acaso, qual é a probabilidade de ela ser azul?',
    options: ['20%', '30%', '40%', '60%'],
    answer: 2,
    explanation: 'Há 2 bolas azuis em um total de 5. A probabilidade é 2/5 = 40%.',
  ),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int coins = 0;
  int bestScore = 0;
  List<String> ranking = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      coins = prefs.getInt('coins') ?? 0;
      bestScore = prefs.getInt('bestScore') ?? 0;
      ranking = prefs.getStringList('ranking') ?? [];
    });
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('coins', coins);
    await prefs.setInt('bestScore', bestScore);
    await prefs.setStringList('ranking', ranking);
  }

  void _startGame() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GamePage(
          onFinish: (score, earnedCoins) async {
            coins += earnedCoins;
            if (score > bestScore) bestScore = score;
            ranking.add('Partida: $score pontos');
            ranking.sort((a, b) {
              final av = int.tryParse(a.split(' ')[1]) ?? 0;
              final bv = int.tryParse(b.split(' ')[1]) ?? 0;
              return bv.compareTo(av);
            });
            if (ranking.length > 10) ranking = ranking.take(10).toList();
            await _saveData();
            if (mounted) setState(() {});
          },
        ),
      ),
    ).then((_) => _loadData());
  }

  void _showRanking() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (context) => Padding(
        padding: const EdgeInsets.all(22),
        child: SizedBox(
          height: 360,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Meu ranking', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('Melhor pontuação: $bestScore pontos'),
              const SizedBox(height: 16),
              Expanded(
                child: ranking.isEmpty
                    ? const Center(child: Text('Jogue uma partida para aparecer aqui.'))
                    : ListView.builder(
                        itemCount: ranking.length,
                        itemBuilder: (_, i) => ListTile(
                          leading: CircleAvatar(child: Text('${i + 1}')),
                          title: Text(ranking[i]),
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: navy,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  const Icon(Icons.monetization_on, color: gold),
                  const SizedBox(width: 6),
                  Text('$coins moedas', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ],
              ),
              const Spacer(),
              const Icon(Icons.workspace_premium, color: gold, size: 76),
              const SizedBox(height: 18),
              const Text(
                'DESAFIO DOS\nCONCUSERIOS',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 32, height: 1.12, fontWeight: FontWeight.w900, letterSpacing: 1),
              ),
              const SizedBox(height: 12),
              const Text(
                'Treine para concursos públicos enquanto joga.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, fontSize: 16),
              ),
              const SizedBox(height: 34),
              _FeatureLine(icon: Icons.favorite, text: '5 vidas por partida'),
              _FeatureLine(icon: Icons.stars, text: 'Pontos e moedas virtuais'),
              _FeatureLine(icon: Icons.trending_up, text: 'Dificuldade progressiva'),
              _FeatureLine(icon: Icons.leaderboard, text: 'Ranking individual'),
              const Spacer(),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: gold,
                  foregroundColor: navy,
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                onPressed: _startGame,
                child: const Text('COMEÇAR JOGO'),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white54),
                  padding: const EdgeInsets.symmetric(vertical: 15),
                ),
                onPressed: _showRanking,
                icon: const Icon(Icons.emoji_events),
                label: const Text('VER MEU RANKING'),
              ),
              const SizedBox(height: 12),
              Text('Melhor resultado: $bestScore pontos', textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70)),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureLine extends StatelessWidget {
  final IconData icon;
  final String text;
  const _FeatureLine({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Icon(icon, color: gold, size: 22),
          const SizedBox(width: 12),
          Text(text, style: const TextStyle(color: Colors.white, fontSize: 15)),
        ],
      ),
    );
  }
}

class GamePage extends StatefulWidget {
  final Future<void> Function(int score, int coins) onFinish;
  const GamePage({super.key, required this.onFinish});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  int index = 0;
  int lives = 5;
  int score = 0;
  int earnedCoins = 0;
  int? selected;
  bool answered = false;
  bool finished = false;

  Question get current => questions[index];
  String get stage {
    if (index < 4) return 'Fase 1 • Fácil';
    if (index < 9) return 'Fase 2 • Médio';
    return 'Fase 3 • Difícil';
  }

  void _answer(int choice) {
    if (answered || finished) return;
    setState(() {
      selected = choice;
      answered = true;
      if (choice == current.answer) {
        score += 10;
        earnedCoins += 2;
      } else {
        lives--;
      }
    });
  }

  Future<void> _next() async {
    if (lives <= 0 || index == questions.length - 1) {
      await _endGame();
      return;
    }
    setState(() {
      index++;
      selected = null;
      answered = false;
    });
  }

  Future<void> _endGame() async {
    if (finished) return;
    setState(() => finished = true);
    await widget.onFinish(score, earnedCoins);
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ResultPage(
          score: score,
          coins: earnedCoins,
          lives: lives,
          total: index + 1,
        ),
      ),
    );
  }

  Color _optionColor(int i) {
    if (!answered) return Colors.white;
    if (i == current.answer) return const Color(0xFFDDF4E5);
    if (i == selected) return const Color(0xFFFFE1E1);
    return Colors.white;
  }

  @override
  Widget build(BuildContext context) {
    if (finished) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(
        title: const Text('Desafio em andamento', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: navy,
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            tooltip: 'Sair da partida',
            onPressed: () => _confirmExit(),
            icon: const Icon(Icons.close),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(stage, style: const TextStyle(fontWeight: FontWeight.bold, color: blue)),
                  Text('Questão ${index + 1}/${questions.length}', style: const TextStyle(fontWeight: FontWeight.w600)),
                ],
              ),
              const SizedBox(height: 10),
              LinearProgressIndicator(value: (index + 1) / questions.length, minHeight: 8, borderRadius: BorderRadius.circular(8)),
              const SizedBox(height: 14),
              Row(
                children: [
                  _StatChip(icon: Icons.favorite, label: '$lives vidas', color: Colors.red),
                  const SizedBox(width: 8),
                  _StatChip(icon: Icons.stars, label: '$score pontos', color: Colors.orange),
                  const SizedBox(width: 8),
                  _StatChip(icon: Icons.monetization_on, label: '$earnedCoins', color: Colors.amber.shade800),
                ],
              ),
              const SizedBox(height: 18),
              Text(current.subject.toUpperCase(), style: const TextStyle(color: blue, fontWeight: FontWeight.bold, letterSpacing: 1)),
              const SizedBox(height: 8),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(current.text, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w700, height: 1.35)),
                      const SizedBox(height: 20),
                      ...List.generate(current.options.length, (i) {
                        final labels = ['A', 'B', 'C', 'D'];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Material(
                            color: _optionColor(i),
                            borderRadius: BorderRadius.circular(14),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(14),
                              onTap: () => _answer(i),
                              child: Container(
                                padding: const EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: answered && (i == current.answer || i == selected)
                                        ? (i == current.answer ? Colors.green : Colors.red)
                                        : Colors.black12,
                                    width: 1.3,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 15,
                                      backgroundColor: blue,
                                      foregroundColor: Colors.white,
                                      child: Text(labels[i], style: const TextStyle(fontWeight: FontWeight.bold)),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(child: Text(current.options[i], style: const TextStyle(fontSize: 15, color: navy))),
                                    if (answered && i == current.answer)
                                      const Icon(Icons.check_circle, color: Colors.green),
                                    if (answered && i == selected && i != current.answer)
                                      const Icon(Icons.cancel, color: Colors.red),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      }),
                      if (answered) ...[
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(12)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(selected == current.answer ? 'Resposta correta! +10 pontos e +2 moedas' : 'Resposta incorreta. Você perdeu uma vida.',
                                  style: TextStyle(fontWeight: FontWeight.bold, color: selected == current.answer ? Colors.green.shade800 : Colors.red.shade800)),
                              const SizedBox(height: 7),
                              Text(current.explanation),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              if (answered)
                FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: blue, padding: const EdgeInsets.symmetric(vertical: 16)),
                  onPressed: _next,
                  child: Text(lives <= 0 || index == questions.length - 1 ? 'VER RESULTADO' : 'PRÓXIMA QUESTÃO'),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmExit() async {
    final leave = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sair da partida?'),
        content: const Text('O resultado desta partida não será contabilizado.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Continuar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sair')),
        ],
      ),
    );
    if (leave == true && mounted) Navigator.pop(context);
  }
}

class _StatChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  const _StatChip({required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 10),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 17, color: color),
            const SizedBox(width: 4),
            Flexible(child: Text(label, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
          ],
        ),
      ),
    );
  }
}

class ResultPage extends StatelessWidget {
  final int score;
  final int coins;
  final int lives;
  final int total;
  const ResultPage({super.key, required this.score, required this.coins, required this.lives, required this.total});

  @override
  Widget build(BuildContext context) {
    final correct = score ~/ 10;
    return Scaffold(
      backgroundColor: navy,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.emoji_events, color: gold, size: 82),
              const SizedBox(height: 20),
              const Text('FIM DE JOGO', textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              Text(lives == 0 ? 'Suas vidas acabaram.' : 'Você concluiu todas as questões!',
                  textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 16)),
              const SizedBox(height: 28),
              _ResultTile(label: 'Pontuação', value: '$score pontos'),
              _ResultTile(label: 'Acertos', value: '$correct de $total'),
              _ResultTile(label: 'Moedas conquistadas', value: '$coins'),
              _ResultTile(label: 'Vidas restantes', value: '$lives'),
              const SizedBox(height: 26),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: navy, padding: const EdgeInsets.symmetric(vertical: 17)),
                onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst),
                child: const Text('VOLTAR AO INÍCIO', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ResultTile extends StatelessWidget {
  final String label;
  final String value;
  const _ResultTile({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.10), borderRadius: BorderRadius.circular(13)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.white70)),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
